function changeText() {
    // Grab the paragraph element by its ID
    let messageParagraph = document.getElementById("messageText");
    
    // Change the text and make it red
    messageParagraph.innerHTML = "<b>Success! The JavaScript is working!</b>";
    messageParagraph.style.color = "red";
}